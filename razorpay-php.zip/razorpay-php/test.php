<?php
require_once('Razorpay.php');
use Razorpay\Api\Api;
$api_key = 'rzp_test_uOxh3fZ3EEWl3J';
$api_secret = 'bV7RPbokIafPmDAm5T2P8EMm';
$api = new Api($api_key, $api_secret);

// Orders
$order  = $api->order->create(array('receipt' => '123', 'amount' => 100, 'currency' => 'INR'));

print_r($order);

?>